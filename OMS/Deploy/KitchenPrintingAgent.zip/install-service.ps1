#requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'
$serviceName = 'KitchenPrintingAgent'
$displayName = 'Kitchen Printing Agent'
$exe = Join-Path $PSScriptRoot 'KitchenPrintingAgent.exe'

if (-not (Test-Path $exe)) { throw "Missing $exe" }

$existing = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($existing) {
	if ($existing.Status -ne 'Stopped') { Stop-Service -Name $serviceName -Force }
	& sc.exe delete $serviceName | Out-Null
	Start-Sleep -Seconds 2
}

& sc.exe create $serviceName binPath= "`"$exe`"" start= auto DisplayName= "`"$displayName`"" | Out-Null
& sc.exe failure $serviceName reset= 86400 actions= restart/5000/restart/15000/restart/60000 | Out-Null
Start-Service -Name $serviceName
Get-Service -Name $serviceName
Write-Host "Installed and started $displayName."
