#requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'
$serviceName = 'KitchenPrintingAgent'
$service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($service) {
	if ($service.Status -ne 'Stopped') { Stop-Service -Name $serviceName -Force }
	& sc.exe delete $serviceName | Out-Null
	Write-Host "Removed $serviceName."
} else {
	Write-Host "$serviceName is not installed."
}
