# Kitchen Printing Agent package
Endpoint: https://oms.khaneazam.com/Kitchen/KitchenPrintFeed.ashx
Run install-service.ps1 from an elevated PowerShell window.
